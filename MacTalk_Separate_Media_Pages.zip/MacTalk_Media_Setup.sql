-- Mac&Talk: live audio sessions + podcast publishing
-- Run this in Supabase Dashboard > SQL Editor using your project owner account.

create extension if not exists pgcrypto;

-- Keep the existing live_sessions table if it already exists; add the fields this dashboard uses.
create table if not exists public.live_sessions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  host text,
  host_name text,
  host_user_id uuid references auth.users(id) on delete cascade,
  emoji text default '🎙️',
  status text not null default 'scheduled' check (status in ('scheduled','live','ended')),
  approved boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.live_sessions add column if not exists title text;
alter table public.live_sessions add column if not exists description text;
alter table public.live_sessions add column if not exists host text;
alter table public.live_sessions add column if not exists host_name text;
alter table public.live_sessions add column if not exists host_user_id uuid references auth.users(id) on delete cascade;
alter table public.live_sessions add column if not exists emoji text default '🎙️';
alter table public.live_sessions add column if not exists status text default 'scheduled';
alter table public.live_sessions add column if not exists approved boolean default true;
alter table public.live_sessions add column if not exists created_at timestamptz default now();

create index if not exists live_sessions_status_created_idx on public.live_sessions(status, created_at desc);
create index if not exists live_sessions_host_idx on public.live_sessions(host_user_id, created_at desc);
alter table public.live_sessions enable row level security;
drop policy if exists "Signed-in users can view approved live sessions" on public.live_sessions;
drop policy if exists "Users can create their own live sessions" on public.live_sessions;
drop policy if exists "Hosts can update their own live sessions" on public.live_sessions;
create policy "Signed-in users can view approved live sessions" on public.live_sessions
  for select to authenticated using (approved = true or host_user_id = auth.uid());
create policy "Users can create their own live sessions" on public.live_sessions
  for insert to authenticated with check (host_user_id = auth.uid());
create policy "Hosts can update their own live sessions" on public.live_sessions
  for update to authenticated using (host_user_id = auth.uid()) with check (host_user_id = auth.uid());

create table if not exists public.podcast_episodes (
  id uuid primary key default gen_random_uuid(),
  host_user_id uuid not null references auth.users(id) on delete cascade,
  host_name text,
  title text not null check (char_length(title) between 1 and 120),
  description text,
  audio_path text not null,
  audio_url text,
  published boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.podcast_episodes
  add column if not exists episode_type text not null default 'podcast';
alter table public.podcast_episodes
  drop constraint if exists podcast_episodes_episode_type_check;
alter table public.podcast_episodes
  add constraint podcast_episodes_episode_type_check
  check (episode_type in ('podcast', 'live_replay'));
create index if not exists podcast_episodes_published_created_idx on public.podcast_episodes(published, created_at desc);
create index if not exists podcast_episodes_host_idx on public.podcast_episodes(host_user_id, created_at desc);
alter table public.podcast_episodes enable row level security;
drop policy if exists "Users can read published podcasts" on public.podcast_episodes;
drop policy if exists "Users can publish their own podcasts" on public.podcast_episodes;
drop policy if exists "Users can update their own podcasts" on public.podcast_episodes;
drop policy if exists "Users can delete their own podcasts" on public.podcast_episodes;
create policy "Users can read published podcasts" on public.podcast_episodes
  for select to authenticated using (published = true or host_user_id = auth.uid());
create policy "Users can publish their own podcasts" on public.podcast_episodes
  for insert to authenticated with check (host_user_id = auth.uid());
create policy "Users can update their own podcasts" on public.podcast_episodes
  for update to authenticated using (host_user_id = auth.uid()) with check (host_user_id = auth.uid());
create policy "Users can delete their own podcasts" on public.podcast_episodes
  for delete to authenticated using (host_user_id = auth.uid());

-- Private audio storage. The dashboard creates short-lived signed URLs for playback.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('podcasts', 'podcasts', false, 104857600, array['audio/webm','audio/mp4','audio/m4a','audio/ogg','audio/mpeg','audio/wav'])
on conflict (id) do update set public = false, file_size_limit = 104857600;

drop policy if exists "Podcast owners can upload audio" on storage.objects;
drop policy if exists "Signed-in users can read podcast audio" on storage.objects;
drop policy if exists "Podcast owners can delete audio" on storage.objects;
create policy "Podcast owners can upload audio" on storage.objects
  for insert to authenticated with check (bucket_id = 'podcasts' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Signed-in users can read podcast audio" on storage.objects
  for select to authenticated using (bucket_id = 'podcasts');
create policy "Podcast owners can delete audio" on storage.objects
  for delete to authenticated using (bucket_id = 'podcasts' and (storage.foldername(name))[1] = auth.uid()::text);

-- Realtime must be enabled in Supabase for broadcast signaling. This app uses browser WebRTC
-- with a public STUN server; some networks/firewalls may require a TURN server for connectivity.
